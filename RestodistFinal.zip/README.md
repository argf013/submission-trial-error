# submission-trial-error
How to run : "npm i" , "npm run start-dev"
Testing : "npm run e2e", "npm run test"
